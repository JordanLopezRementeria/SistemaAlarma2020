package es.jordan.apiariojordan2402;

import java.util.ArrayList;

public class Apiario {
    private int idApiario;
    private int idUsuario; //id del usuario que tiene ese colmenar
    private String nombreApiario;

}